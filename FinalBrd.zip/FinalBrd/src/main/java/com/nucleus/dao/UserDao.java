package com.nucleus.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.nucleus.entity.User;

@Repository
public class UserDao implements UserDaoI 
{
	static Logger log = Logger.getLogger(UserDao.class.getName());
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public void save(User user)
	{
		sessionFactory.getCurrentSession().save(user);
		
	}

	@Override
	public List<User> viewUserName() 
	{
		List<User> userName=new ArrayList<User>();
		Query query=sessionFactory.getCurrentSession().createQuery(" from User");
		userName=query.list();
		return userName;
	}

	@Override
	public User checkUserName(String username) {
		Query query=sessionFactory.getCurrentSession().createQuery("from User where username=:abc");
		query.setParameter("abc", username);
		return (User) query.uniqueResult();
	}

}
