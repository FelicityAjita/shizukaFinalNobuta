package com.nucleus.dao;

import java.util.List;

import com.nucleus.entity.User;

public interface UserDaoI {

	public void save(User user);
	public List<User> viewUserName(); 
	public User checkUserName(String username);
	
}
