package com.nucleus.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.nucleus.dao.UserDaoI;
import com.nucleus.entity.User;

@Service
public class UserService implements UserServiceI {

	static Logger log = Logger.getLogger(UserService.class.getName());
	
	@Autowired
	UserDaoI  userDao;
	
	@Transactional
	@Override
	public void save(User user) 
	{
		EncodingPassword passwordEncode=new EncodingPassword();
		passwordEncode.encrptPass(user);
		userDao.save(user);
		
	}

	@Transactional
	@Override
	public List<String> viewUserName() 
	{
		return userDao.viewUserName();
	}

}
