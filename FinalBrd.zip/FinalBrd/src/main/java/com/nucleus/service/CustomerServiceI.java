package com.nucleus.service;

import java.util.List;

import com.nucleus.entity.Customer;

public interface CustomerServiceI 
{

	public int addCustomer(Customer customer);
	public int deleteCustomer(Customer customerCode);
	public List<Customer> viewAll();
	public List<Customer> viewById(int customerCode);
	public int updateCustomer(Customer customer);
	public List<Customer> viewByName(String name);
}
