package com.nucleus.service;

import org.apache.log4j.Logger;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


import com.nucleus.entity.User;

public class EncodingPassword
{
	static Logger log = Logger.getLogger(EncodingPassword.class.getName());
	
			BCryptPasswordEncoder passwordEncoder=new BCryptPasswordEncoder() ;
			
			public void encrptPass(User user)
			{
				//User u=new User();
				String pass=passwordEncoder.encode(user.getPassword());
				user.setPassword(pass);
				
			}
}
