package com.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SecurityController {
	@RequestMapping("/login")
	public String loginHandler()
	{
		return "login";
	}
	
	@RequestMapping("/")
	public String loginHandler1()
	{
		return "login";
	}
	
	@RequestMapping("/accessdenied")
	public String accessDeniedHandler()
	{
		return "accessdenied";
	}
	
	@RequestMapping("/logoutpage")
	public String logoutHandler()
	{
		return "login";
	}
	
}
