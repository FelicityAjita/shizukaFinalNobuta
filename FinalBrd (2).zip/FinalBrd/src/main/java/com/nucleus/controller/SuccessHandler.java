package com.nucleus.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;


public class SuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler
{
	static Logger log = Logger.getLogger(SuccessHandler.class.getName());
	@Override
	protected String determineTargetUrl(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
		String role=auth.getAuthorities().toString();
	      User user=(User) auth.getPrincipal();
	      System.out.println(user.getUsername());
	      System.out.println("+++++++++++++++++++++++"+role);
	     String targetUrl=" ";
		if(role.contains("ROLE_USER"))
		{
			targetUrl="/frames/"+user.getUsername();
		}
		else if(role.contains("ROLE_ADMIN"))
		{
			targetUrl="/adminMenu";
		}
		
		return targetUrl;
	}
	
	
	
	
}
