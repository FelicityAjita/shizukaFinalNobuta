package com.nucleus.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.entity.Customer;

import com.nucleus.service.CustomerServiceI;

@Controller
public class UserController 
{
	
	static Logger log = Logger.getLogger(UserController.class.getName());
	
	@Autowired
	CustomerServiceI customerService;
	
	@ModelAttribute("customer")
	public Customer getCustomer()
	{
		return new Customer();
	}

	String userName;
	
	//==== First Page ========
	
	@RequestMapping(value="/frames/{username}")
	public String menu(@PathVariable("username") String username)
	{
		this.userName=username;
		return "frames";
	}
	
	
	@RequestMapping(value="/userMenu")
	public String menu1()
	{
		
		return "userMenu";
	}
	
	//=== Add Part ======
	
		@RequestMapping(value="/add")
		public String add(@ModelAttribute("customer") Customer customer)
		{
			return "addCustomer";
		}
		
		@RequestMapping(value="/addCustomer", method=RequestMethod.POST)
		public String addVendor(@ModelAttribute("customer")  @Valid Customer customer,BindingResult result)
		{
			  if(result.hasErrors()) {
		    	    return "addCustomer";
		        }
			  
			customer.setCreatedBy(userName);
			customerService.addCustomer(customer);
			return "success";
		}
		
		//====== UPDATE =====
		
		@RequestMapping(value="/update")
		public String update()
		{
			return "updateId";
		}
		
		@RequestMapping(value="/updateId")
		public ModelAndView updateId(@RequestParam("customerCode") String customerCode)
		{
			try{
			List<Customer> customer=customerService.viewById(Integer.parseInt(customerCode));
			if(customer.size()==0)
			{
				return new ModelAndView("tryAgain");
			}
			else
			{
			Customer cust=customer.get(0);
			return new ModelAndView("updateForm","customer",cust);
			}}
			catch(Exception e)
			{
				return new ModelAndView("invalid");
			}
			
		}
		
		@RequestMapping(value="/updated" ,method=RequestMethod.POST)
		public String updateData(@ModelAttribute("c") Customer cust)
		{
		
			customerService.updateCustomer(cust);
			return "success";
		
		}
		
		//===   Delete Part =====
	 	
		@RequestMapping(value="/remove")
		public String remove()
		{
			return "deleteId";
		}
		
		@RequestMapping(value="/deleteId" ,method=RequestMethod.POST) 
		public String deleteId(@RequestParam("customerCode") String customerCode)
		{
			try{
			List<Customer> customer=customerService.viewById(Integer.parseInt(customerCode));
			if(customer.size()==0)
			{
				return "tryAgain";
			}
			else
			{
			
			Customer c=new Customer();
			c.setCustomerCode(Integer.parseInt(customerCode));
			customerService.deleteCustomer(c);
			return "success";
			}
			}
			catch(Exception e)
			{
				return "invalid";
			}
			
		}
		
		//=== View Part
		
		@RequestMapping(value="/view")
		public String view(Model model)
		{
			List<Customer> vcustomer=(ArrayList<Customer>) customerService.viewAll();
			int length=vcustomer.size();
			System.out.println(length);
			model.addAttribute("c", vcustomer);
			return "ViewCustomer";
			
		}
		
		@RequestMapping(value="/singleview")
		public String singleView()
		{
			return "viewId";
			
		}
		
		@RequestMapping(value="/viewId",method=RequestMethod.POST)
		public ModelAndView viewId(@RequestParam("customerCode") String customerCode)
		{
		
			try{
			List<Customer> customer1=customerService.viewById(Integer.parseInt(customerCode));
			System.out.println(customer1+"    :Single view LIST HERE");
			
			if(customer1.size()==0)
			{
				return new ModelAndView("tryAgain");
			}
			return new ModelAndView("singleView","c",customer1);
			}
			catch(Exception e)
			{
				return new ModelAndView("invalid");
			}
		}
		
		@RequestMapping(value="SingleviewName" , method=RequestMethod.GET)
		public String name()
		{
			return "viewName";
		}
		
		
		@RequestMapping(value="viewName" , method=RequestMethod.POST)
		public ModelAndView viewName(@RequestParam("name") String name)
		{
			List<Customer> customer=customerService.viewByName(name);
			System.out.println("SIZE OF LIST IN VIEWALL : :"+customer.size());
			if(customer.size()==0)
			{
				return new ModelAndView("tryAgain");
			}
			return new ModelAndView("singleView","c",customer);
			
		}
		//== View end =====
		
	
	
}
