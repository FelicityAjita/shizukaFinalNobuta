package com.nucleus.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.CustomerDaoI;
import com.nucleus.entity.Customer;

@Transactional
@Service
public class CustomerService implements CustomerServiceI{

	static Logger log = Logger.getLogger(CustomerService.class.getName());
	
	
	@Autowired
	//@Qualifier("daomine")
	CustomerDaoI customerDao;
	
	
	@Override
	public int addCustomer(Customer customer) {
		return customerDao.addCustomer(customer);
	}

	@Override
	public int deleteCustomer(Customer customerCode) {
		return customerDao.deleteCustomer(customerCode);
	}

	@Override
	public List<Customer> viewAll() {
		return customerDao.viewAll();
	}

	@Override
	public List<Customer> viewById(int customerCode) {
		return customerDao.viewById(customerCode);
	}

	@Override
	public int updateCustomer(Customer customer) {
		return customerDao.updateCustomer(customer);
	}

	@Override
	public List<Customer> viewByName(String name) {
		return customerDao.viewByName(name);
	}

}
