package com.nucleus.service;

import java.util.List;

import com.nucleus.entity.User;

public interface UserServiceI 
{

	public void save(User user);
	public List<User> viewUserName(); 
	public User checkUserName(String username);
}
