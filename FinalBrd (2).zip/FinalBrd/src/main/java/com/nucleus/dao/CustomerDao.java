package com.nucleus.dao;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.nucleus.entity.Customer;

@Repository
public class CustomerDao implements CustomerDaoI {

	static Logger log = Logger.getLogger(CustomerDao.class.getName());
	
	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public int addCustomer(Customer customer) 
	{
		  Date dNow = new Date( );
	      SimpleDateFormat ft = new SimpleDateFormat ("dd/MMM/yyyy");
	      customer.setRegistrationDate(ft.format(dNow));
	      
		sessionFactory.getCurrentSession().save(customer);
		return 0;
	}

	@Override
	public int deleteCustomer(Customer customerCode) 
	{
		/*Customer theCustomer = session.get(Customer.class,customerCode);
		delete(theCustomer);*/
		
		sessionFactory.getCurrentSession().delete(customerCode);
		return 0;
	}

	@Override
	public List<Customer> viewAll() 
	{
		Query query=sessionFactory.getCurrentSession().createQuery("from Customer");
		List<Customer> customer = query.list();
		return customer;
	}

	@Override
	public List<Customer> viewById(int customerCode) {
		Query query=sessionFactory.getCurrentSession().createQuery("from Customer where customerCode=:customerCode");
		query.setParameter("customerCode", customerCode);
		List<Customer> customer=query.list();
		return customer;
	}

	@Override
	public int updateCustomer(Customer customer) {
		 Date dNow = new Date( );
	      SimpleDateFormat ft = 
	      new SimpleDateFormat ("dd/MMM/yyyy");
	      customer.setModifiedDate(ft.format(dNow));
		sessionFactory.getCurrentSession().saveOrUpdate(customer);
		return 0;
	}

	@Override
	public List<Customer> viewByName(String name) {
		Query query=sessionFactory.getCurrentSession().createQuery("from Customer where name=:name");
		query.setParameter("name", name);
		List<Customer> customer=query.list();
		return customer;
	}

}
